const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const bodyParser = require('body-parser');
const path = require('path');
const { auth } = require('express-openid-connect');
const app = express();
const port = 3000;
const config = {
  authRequired: false,
  auth0Logout: true,
  secret: 'a long, randomly-generated string stored in env',
  baseURL: 'http://localhost:3000',
  clientID: '3UxnbyHAWuOdUpEzMF4jpcw0AbbebKoX',
  issuerBaseURL: 'https://railway-compass.us.auth0.com',
};
app.use(auth(config));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
const uri = "mongodb+srv://sarvani:Sarvani$2324@railwayscluster.1svsz.mongodb.net/?retryWrites=true&w=majority&appName=RailwaysCluster";
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
const dbName = "eventDB";
const collectionName = "events";
app.get('/', (req, res) => {
  if (req.oidc.isAuthenticated()) {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  } else {
    res.redirect('/login');
  }
});
app.get('/logout', (req, res) => {
  req.logout();
  res.redirect('/');
});
async function connectDB() {
  try {
    await client.connect();
    console.log("Connected to MongoDB Atlas");
  } catch (err) {
    console.error("Error connecting to MongoDB:", err);
  }
}
connectDB();
app.post('/events', async (req, res) => {
  const { name, phone, email, eventName, eventDate } = req.body;

  if (!name || !phone || !email || !eventName || !eventDate) {
    return res.status(400).send({ message: "All fields are required" });
  }

  try {
    const db = client.db(dbName);
    const result = await db.collection(collectionName).insertOne(req.body);
    res.status(201).send({ message: "Event added successfully", id: result.insertedId });
  } catch (err) {
    console.error(err);
    res.status(500).send({ message: "Error adding event" });
  }
});
app.get('/events', async (req, res) => {
  try {
    const db = client.db(dbName);
    const events = await db.collection(collectionName).find().toArray();
    res.status(200).send(events);
  } catch (err) {
    console.error(err);
    res.status(500).send({ message: "Error retrieving events" });
  }
});
app.put('/events/:id', async (req, res) => {
  const { id } = req.params;

  if (!ObjectId.isValid(id)) {
    return res.status(400).send({ message: "Invalid ID" });
  }

  try {
    const db = client.db(dbName);
    const result = await db.collection(collectionName).updateOne(
      { _id: new ObjectId(id) },
      { $set: req.body }
    );

    if (result.matchedCount === 0) {
      return res.status(404).send({ message: "Event not found" });
    }

    res.status(200).send({ message: "Event updated successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).send({ message: "Error updating event" });
  }
});
app.delete('/events/:id', async (req, res) => {
  const { id } = req.params;

  if (!ObjectId.isValid(id)) {
    return res.status(400).send({ message: "Invalid ID" });
  }

  try {
    const db = client.db(dbName);
    const result = await db.collection(collectionName).deleteOne({ _id: new ObjectId(id) });

    if (result.deletedCount === 0) {
      return res.status(404).send({ message: "Event not found" });
    }

    res.status(200).send({ message: "Event deleted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).send({ message: "Error deleting event" });
  }
});
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

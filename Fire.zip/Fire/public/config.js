
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyD0mq-vbIWNy6YI5jn7qEArCg18LfAHrUY",
    authDomain: "cloud-95f5f.firebaseapp.com",
    projectId: "cloud-95f5f",
    storageBucket: "cloud-95f5f.firebasestorage.app",
    messagingSenderId: "1050105849040",
    appId: "1:1050105849040:web:ec315c370f53d2dbed6ad5",
    measurementId: "G-GT93SJN0DW"
  };
// Initialize Firebase
const app = initializeApp(firebaseConfig);

const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

let events = []; 

app.use(express.json()); 
app.use(express.static(path.join(__dirname, 'public'))); 

// API: Fetch all events
app.get('/api/events', (req, res) => {
    res.json(events);
});

app.get('/api/events/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const event = events.find(e => e.id === id);
    if (event) {
        res.json(event);
    } else {
        res.status(404).send('Event not found');
    }
});

app.post('/api/events', (req, res) => {
    const { name, phone, email, eventName, eventDate } = req.body;
    if (!name || !phone || !email || !eventName || !eventDate ) {
        return res.status(400).send('All fields are required.');
    }
    const event = {
        id: events.length ? events[events.length - 1].id + 1 : 1, 
        name,
        phone,
        email,
        eventName,
        eventDate,
    };
    events.push(event);

    console.log('Event added:', event); 
    res.status(201).json(event);
});
app.put('/api/events/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const { name, phone, email, eventName, eventDate  } = req.body;

    const index = events.findIndex(e => e.id === id);

    if (index === -1) {
        return res.status(404).send('Event not found');
    }
    if (!name || !phone || !email || !eventName || !eventDate ) {
        return res.status(400).send('All fields are required.');
    }
    events[index] = {
        id,
        name,
        phone,
        email,
        eventName,
        eventDate,
    };

    console.log('Event updated:', events[index]); 
    res.json(events[index]);
});
app.delete('/api/events/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = events.findIndex(e => e.id === id);

    if (index === -1) {
        return res.status(404).send('Event not found');
    }
    events.splice(index, 1);
    console.log(`Event with ID ${id} deleted`); 
    res.send(`Event with ID ${id} deleted`);
});
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

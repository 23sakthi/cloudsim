const express = require('express');
const axios = require('axios');
const path = require('path');
const app = express();

const API_KEY = '660bc5dd24551c733cd624b5';
const API_URL = `https://v6.exchangerate-api.com/v6/${API_KEY}/latest/USD`;

let currencyList = []; // Cache for currency list

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Fetch currency list from the API
app.get('/currencies', async (req, res) => {
    try {
        if (!currencyList.length) {
            const response = await axios.get(API_URL);
            currencyList = Object.keys(response.data.conversion_rates);
        }
        res.json({ currencies: currencyList });
    } catch (error) {
        res.status(500).json({ error: 'Error fetching currency list.' });
    }
});

// Convert currency
app.post('/convert', async (req, res) => {
    const { amount, fromCurrency, toCurrency } = req.body;
    try {
        const response = await axios.get(`${API_URL.replace('USD', fromCurrency)}`);
        const rate = response.data.conversion_rates[toCurrency];
        const convertedAmount = (amount * rate).toFixed(2);
        res.json({ convertedAmount });
    } catch (error) {
        res.status(500).json({ error: 'Error fetching exchange rates. Please try again.' });
    }
});

app.listen(3000, () => {
    console.log('Currency Converter app is running at http://localhost:3000');
});

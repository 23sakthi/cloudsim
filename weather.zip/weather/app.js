const express = require('express');
const axios = require('axios');
const path = require('path');
const app = express();

const API_KEY = '309d046ab271485b8a443536242411';
const WEATHER_API_URL = `http://api.weatherapi.com/v1/current.json?key=${API_KEY}`;
const GEO_API_URL = `http://api.weatherapi.com/v1/search.json?key=${API_KEY}`;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.post('/weather', async (req, res) => {
    const { location } = req.body;
    try {
        const response = await axios.get(`${WEATHER_API_URL}&q=${location}&aqi=no`);
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching weather data. Please check the location and try again.' });
    }
});
app.get('/locations/:query', async (req, res) => {
    const { query } = req.params;
    try {
        const response = await axios.get(`${GEO_API_URL}&q=${query}`);
        res.json(response.data); 
    } catch (error) {
        res.status(500).json({ error: 'Error fetching locations. Please try again.' });
    }
});

app.listen(3000, () => {
    console.log('Weather app is running at http://localhost:3000');
});

const express = require('express');
const multer = require('multer');
const bodyParser = require('body-parser');
const Dropbox = require('dropbox').Dropbox;
const fetch = require('isomorphic-fetch');
const path = require('path');

const app = express();
const port = 3000;
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
let events = [];
const dbx = new Dropbox({
    accessToken: 'sl.CBSdUma0o_92hGpmNpBc1XdQO7A8kAKt68fiiMtWjssOKFIZbnstCOa8amN1f-kUpjKUXp20BfvE__lBwdy5RyOnPppNRWPzPnacJ2eWA7qlY0aFG8JyxB_iyO6UEY8ulRQKhG7Oubjhjr78CD8HGNA',
    fetch: fetch,
});
const storage = multer.memoryStorage();
const upload = multer({ storage });
app.get('/api/events', (req, res) => {
    res.json(events);
});
app.get('/api/events/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const event = events.find(e => e.id === id);
    if (event) {
        res.json(event);
    } else {
        res.status(404).send('Event not found');
    }
});
app.post('/api/events', upload.single('doc'), async (req, res) => {
    const { name, phone, email, eventName, eventDate } = req.body;
    if (!name || !phone || !email || !eventName || !eventDate) {
        return res.status(400).send('All fields are required.');
    }
    let docUrl = null;
    if (req.file) {
        try {
            const dropboxPath = `/EventDocs/${req.file.originalname}`;
            const response = await dbx.filesUpload({
                path: dropboxPath,
                contents: req.file.buffer,
            });
            const sharedLink = await dbx.sharingCreateSharedLink({
                path: response.result.path_display,
            });
            docUrl = sharedLink.result.url.replace('?dl=0', '?raw=1');
        } catch (error) {
            console.error('Error uploading file to Dropbox:', error);
            return res.status(500).json({ message: 'File upload failed' });
        }
    }
    const event = {
        id: events.length ? events[events.length - 1].id + 1 : 1,
        name,
        phone,
        email,
        eventName,
        eventDate,
        docUrl,
    };

    events.push(event);
    res.status(201).json(event);
});
app.put('/api/events/:id', upload.single('doc'), async (req, res) => {
    const id = parseInt(req.params.id);
    const eventIndex = events.findIndex(e => e.id === id);
    if (eventIndex === -1) {
        return res.status(404).send('Event not found');
    }

    const { name, phone, email, eventName, eventDate } = req.body;
    let docUrl = events[eventIndex].docUrl; 
    if (req.file) {
        try {
            const dropboxPath = `/EventDocs/${req.file.originalname}`;
            const response = await dbx.filesUpload({
                path: dropboxPath,
                contents: req.file.buffer,
            });
            const sharedLink = await dbx.sharingCreateSharedLink({
                path: response.result.path_display,
            });
            docUrl = sharedLink.result.url.replace('?dl=0', '?raw=1');
        } catch (error) {
            console.error('Error uploading file to Dropbox:', error);
            return res.status(500).json({ message: 'File upload failed' });
        }
    }
    const updatedEvent = {
        id,
        name: name || events[eventIndex].name,
        phone: phone || events[eventIndex].phone,
        email: email || events[eventIndex].email,
        eventName: eventName || events[eventIndex].eventName,
        eventDate: eventDate || events[eventIndex].eventDate,
        docUrl,
    };

    events[eventIndex] = updatedEvent;
    res.json(updatedEvent);
});
app.delete('/api/events/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = events.findIndex(e => e.id === id);
    if (index === -1) {
        return res.status(404).send('Event not found');
    }
    events.splice(index, 1);
    res.send(`Event with ID ${id} deleted`);
});
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
